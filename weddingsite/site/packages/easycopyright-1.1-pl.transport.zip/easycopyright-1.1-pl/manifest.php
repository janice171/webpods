<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '3d00047987fa46fd5614305e6b52dad8',
      'native_key' => 'easycopyright',
      'filename' => 'modNamespace/7a34c3fecca45acc652f9bedf9495540.vehicle',
      'namespace' => 'easycopyright',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '020da322ef44fe3a741d40f2866e60f4',
      'native_key' => 1,
      'filename' => 'modCategory/3165ae288ce1e8a654d49884cece01cb.vehicle',
      'namespace' => 'easycopyright',
    ),
  ),
);